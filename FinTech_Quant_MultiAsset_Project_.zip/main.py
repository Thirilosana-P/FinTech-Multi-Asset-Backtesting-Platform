import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from pathlib import Path

try:
    import yfinance as yf
except ImportError:
    yf = None

st.set_page_config(page_title="Quantitative Multi-Asset Financial Intelligence", layout="wide")

DATA = Path(__file__).parent / "data"

@st.cache_data
def load_demo_asset(asset):
    path = DATA / f"{asset.lower()}_demo.csv"
    df = pd.read_csv(path, parse_dates=["Date"])
    return df.sort_values("Date").reset_index(drop=True)

TICKERS = {"Gold": "GC=F", "Bitcoin": "BTC-USD", "NVIDIA": "NVDA"}

@st.cache_data(ttl=900)
def load_live_asset(asset, period="2y"):
    if yf is None:
        return None
    try:
        data = yf.download(TICKERS[asset], period=period, auto_adjust=False, progress=False)
        if data is None or data.empty:
            return None
        if isinstance(data.columns, pd.MultiIndex):
            data.columns = data.columns.get_level_values(0)
        needed = ["Open", "High", "Low", "Close", "Volume"]
        data = data[[c for c in needed if c in data.columns]].dropna().reset_index()
        dates = pd.to_datetime(data["Date"])
        if getattr(dates.dt, "tz", None) is not None:
            dates = dates.dt.tz_localize(None)
        data["Date"] = dates
        return data
    except Exception:
        return None

def load_asset(asset, source="Demo CSV"):
    if source == "Live market data (yFinance)":
        live = load_live_asset(asset)
        if live is not None and not live.empty:
            return live
    return load_demo_asset(asset)

def indicators(df, sma=20, ema=20):
    d = df.copy()
    d["SMA"] = d["Close"].rolling(sma).mean()
    d["EMA"] = d["Close"].ewm(span=ema, adjust=False).mean()
    d["Daily Return"] = d["Close"].pct_change()
    d["Cumulative Return"] = (1 + d["Daily Return"].fillna(0)).cumprod() - 1
    d["Rolling Volatility"] = d["Daily Return"].rolling(20).std() * np.sqrt(252)
    return d

def max_drawdown(series):
    wealth = (1 + series.fillna(0)).cumprod()
    peak = wealth.cummax()
    return (wealth / peak - 1).min()

def historical_var(series, confidence=0.95):
    r = series.dropna()
    if r.empty:
        return 0.0
    return float(r.quantile(1 - confidence))

def sharpe(series):
    r = series.dropna()
    if r.std() == 0:
        return 0.0
    return (r.mean() / r.std()) * np.sqrt(252)

def backtest_sma(d):
    x = d.copy()
    x["Signal"] = (x["SMA"] > x["EMA"]).astype(int)
    x["Position"] = x["Signal"].shift(1).fillna(0)
    x["Strategy Return"] = x["Position"] * x["Daily Return"].fillna(0)
    x["Strategy Equity"] = (1 + x["Strategy Return"]).cumprod()
    x["BuyHold Equity"] = (1 + x["Daily Return"].fillna(0)).cumprod()
    return x

st.title("Quantitative Multi-Asset Financial Intelligence & Backtesting Platform")
st.caption("Demo/offline dataset • Quantitative research and historical analysis only")

st.markdown("### Main Concept")
st.write("Analyze Gold, Bitcoin and NVIDIA using historical OHLCV-style data, indicators, returns, risk, correlation and strategy backtesting.")
assets = ["Gold", "Bitcoin", "NVIDIA"]
source = st.sidebar.selectbox("Data Source", ["Demo CSV", "Live market data (yFinance)"])
st.caption(f"Current data source: {source}")
asset = st.sidebar.selectbox("Select Asset", assets)
sma = st.sidebar.slider("SMA Period", 5, 100, 20)
ema = st.sidebar.slider("EMA Period", 5, 100, 20)

raw = load_asset(asset, source)
df = indicators(raw, sma, ema)
bt = backtest_sma(df)

# Market regime labels based on rolling return/volatility.
df["Regime"] = "Low Volatility"
df.loc[df["Rolling Volatility"] > df["Rolling Volatility"].median() * 1.35, "Regime"] = "High Volatility"
df.loc[df["Close"].pct_change(60) > 0.08, "Regime"] = "Bull Market"
df.loc[df["Close"].pct_change(60) < -0.08, "Regime"] = "Bear Market"

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Return", f"{df['Cumulative Return'].iloc[-1]*100:.2f}%")
c2.metric("Sharpe Ratio", f"{sharpe(df['Daily Return']):.2f}")
c3.metric("Max Drawdown", f"{max_drawdown(df['Daily Return'])*100:.2f}%")
c4.metric("Annualized Volatility", f"{df['Daily Return'].std()*np.sqrt(252)*100:.2f}%")

st.subheader("New: Risk & Portfolio Analysis")
r1, r2 = st.columns(2)
var95 = historical_var(df["Daily Return"], 0.95)
with r1:
    st.metric("Historical VaR (95%, daily)", f"{var95*100:.2f}%")
    st.caption("Historical VaR estimates a loss threshold from past daily returns.")
with r2:
    st.write("**Equal-weight portfolio**")
    returns = pd.DataFrame({
        a: load_asset(a, source).set_index("Date")["Close"].pct_change()
        for a in assets
    }).dropna()
    portfolio_return = returns.mean(axis=1)
    portfolio_equity = (1 + portfolio_return).cumprod()
    st.metric("Portfolio Return", f"{(portfolio_equity.iloc[-1]-1)*100:.2f}%")
    st.metric("Portfolio Volatility", f"{portfolio_return.std()*np.sqrt(252)*100:.2f}%")
st.line_chart(portfolio_equity.rename("Equal-Weight Portfolio"))

st.subheader(f"1. Price Chart — {asset}")
fig = go.Figure()
fig.add_trace(go.Candlestick(x=df["Date"], open=df["Open"], high=df["High"], low=df["Low"], close=df["Close"], name="Price"))
fig.add_trace(go.Scatter(x=df["Date"], y=df["SMA"], name="SMA"))
fig.add_trace(go.Scatter(x=df["Date"], y=df["EMA"], name="EMA"))
fig.update_layout(height=500, xaxis_rangeslider_visible=False)
st.plotly_chart(fig, use_container_width=True)

st.subheader("2. Quantitative Analysis")
q1, q2 = st.columns(2)
with q1:
    st.write("**Daily & Cumulative Returns**")
    st.line_chart(df.set_index("Date")[["Cumulative Return"]])
with q2:
    st.write("**Rolling Volatility**")
    st.line_chart(df.set_index("Date")[["Rolling Volatility"]])

st.subheader("3. Correlation Analysis")
all_close = pd.DataFrame({a: load_asset(a, source).set_index("Date")["Close"] for a in assets})
st.dataframe(all_close.pct_change().corr().round(3), use_container_width=True)

st.subheader("4. SMA/EMA Backtesting")
st.write("Strategy rule: hold the asset when SMA is above EMA; otherwise stay out. This is a simple research example, not investment advice.")
bt_ret = bt["Strategy Return"].dropna()
buyhold_ret = bt["Daily Return"].fillna(0)
b1, b2, b3 = st.columns(3)
b1.metric("Strategy Return", f"{(bt['Strategy Equity'].iloc[-1]-1)*100:.2f}%")
b2.metric("Buy & Hold Return", f"{(bt['BuyHold Equity'].iloc[-1]-1)*100:.2f}%")
b3.metric("Strategy Sharpe", f"{sharpe(bt_ret):.2f}")

eq = bt.set_index("Date")[["Strategy Equity", "BuyHold Equity"]]
st.line_chart(eq)

st.subheader("5. Market Regime Analysis")
regime_counts = df["Regime"].value_counts()
st.bar_chart(regime_counts)

st.subheader("6. Data Preview")
st.dataframe(raw.tail(20), use_container_width=True)

st.info("The included CSV files are offline DEMO datasets created to match the problem statement's data structure. Replace them with verified historical market data for real research.")
