# Quantitative Multi-Asset Financial Intelligence & Backtesting Platform

Educational quantitative-finance dashboard for Gold, Bitcoin and NVIDIA.

## Added features
- Live historical market-data option using **yFinance** (with offline CSV fallback)
- Historical **95% Value at Risk (VaR)** estimate
- Equal-weight **multi-asset portfolio analysis**
- Portfolio return and annualized volatility
- Existing SMA, EMA, returns, Sharpe ratio, maximum drawdown, correlation, backtesting, buy-and-hold and market-regime analysis

## Technologies
Python, Pandas, NumPy, Plotly, Streamlit, yFinance.

## Run
```bash
python -m pip install -r requirements.txt
python -m streamlit run main.py
```

The included CSV files are synthetic offline DEMO datasets. Live mode requires internet access and depends on yFinance/Yahoo Finance availability. This project is for historical quantitative research and software demonstration, not investment advice.
